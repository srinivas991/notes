<?php
header('location:index.php?reg=1');
?>